<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class FcDefaultMenu extends Model
{
    protected $table = 'fc_default_menu';
}
