<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class food_family extends Model
{
    //
    protected $table = 'fc_food_families';
}
