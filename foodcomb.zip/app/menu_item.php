<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class menu_item extends Model
{
    //
    protected $table = 'fc_menu_items';
}
