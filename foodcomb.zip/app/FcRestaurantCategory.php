<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class FcRestaurantCategory extends Model
{
  protected $table = 'fc_restaurant_categories';

}
