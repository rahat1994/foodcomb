<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class DailySpecial extends Model
{
    
}
