<link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
<?php /**PATH C:\xampp\htdocs\final_year\foodcomb\vendor\tcg\voyager\src/../resources/views/partials/select_two.blade.php ENDPATH**/ ?>